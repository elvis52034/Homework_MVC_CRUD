﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HW1060629_CRUD.Models;

namespace HW1060629_CRUD.Controllers
{
    public class HomeController : Controller
    {

        drinkShopEntities db = new drinkShopEntities();

        // GET: Home
        public ActionResult Index()
        {
            var list = db.Products.OrderBy(m => m.Price).ToList();
            return View(list);
        }

        public ActionResult Delete(int id)
        {
            var tea = db.Products.Where(m => m.ID==id).FirstOrDefault();
            db.Products.Remove(tea);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(int ID,string Drink, string Type, double Price)
        {
            Product tea = new Product();
            tea.ID = ID;
            tea.Drink = Drink;
            tea.Type = Type;
            tea.Price = Price;
            db.Products.Add(tea);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Edit(int id)
        {
            var tea = db.Products.Where(m => m.ID == id).FirstOrDefault();
                return View(tea);
        }

        [HttpPost]
        public ActionResult Edit(int ID, string Drink, string Type, int Price)
        {
            var tea = db.Products.Where(m => m.ID == ID).FirstOrDefault();
            tea.ID = ID;
            tea.Drink = Drink;
            tea.Type = Type;
            tea.Price = Price;
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}